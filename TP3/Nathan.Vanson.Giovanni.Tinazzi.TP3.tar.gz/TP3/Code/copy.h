#ifndef COPY_H_INCLUDED
#define COPY_H_INCLUDED

void CopyFiles(char* dir_src, char* dir_dest);

#endif // COPY_H_INCLUDED