#ifndef LISTING_H_INCLUDED
#define LISTING_H_INCLUDED

void RecursiveFuncList(char* dir_entry);
void lireDroitFichier(char* dir_entry, char roles[10]);

#endif // LISTING_H_INCLUDED